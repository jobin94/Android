package com.example.triall;

import android.app.AlertDialog;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class Insert extends AppCompatActivity {
    EditText id, name, designation;
    Button btnAdd;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert);


        id = (EditText) findViewById(R.id.id);
        name = (EditText) findViewById(R.id.name);
        designation = (EditText) findViewById(R.id.designation);
        btnAdd = (Button) findViewById(R.id.btnAdd);


        db = openOrCreateDatabase("EmployeeDB", Context.MODE_PRIVATE, null);
        if (db != null) {
            Toast.makeText(this, "Ctreated", Toast.LENGTH_SHORT).show();
        }
        db.execSQL("CREATE TABLE IF NOT EXISTS employee(empid VARCHAR,name VARCHAR,salary VARCHAR);");

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (id.getText().toString().trim().length() == 0 ||
                        name.getText().toString().trim().length() == 0 ||
                        designation.getText().toString().trim().length() == 0) {
                    showMessage("Error", "Please enter all values");
                    return;
                }
                db.execSQL("INSERT INTO employee VALUES('" + id.getText() + "','" + name.getText() +
                        "','" + designation.getText() + "');");
                showMessage("Success", "Record added");
                clearText();
            }
        });



    }

    public void showMessage(String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

    public void clearText() {
        id.setText("");
        name.setText("");
        designation.setText("");
        id.requestFocus();
    }

}
